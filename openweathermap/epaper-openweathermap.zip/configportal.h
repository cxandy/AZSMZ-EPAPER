/**The MIT License (MIT)
Copyright (c) 2017 by Daniel Eichhorn
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
See more at http://blog.squix.ch
*/

#include <ESP8266WebServer.h>
#include <MiniGrafx.h>

const char HTTP_HEAD[] PROGMEM            = "<!DOCTYPE html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\"/><title>{v}</title>";
const char HTTP_STYLE[] PROGMEM           = "<style>.c{text-align: center;} div,input, select{padding:5px;font-size:1em;} input, select{width:95%;} body{text-align: center;font-family:verdana;} button{border:0;border-radius:0.3rem;background-color:#1fa3ec;color:#fff;line-height:2.4rem;font-size:1.2rem;width:100%;} .q{float: right;width: 64px;text-align: right;} .l{background: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAALVBMVEX///8EBwfBwsLw8PAzNjaCg4NTVVUjJiZDRUUUFxdiZGSho6OSk5Pg4eFydHTCjaf3AAAAZElEQVQ4je2NSw7AIAhEBamKn97/uMXEGBvozkWb9C2Zx4xzWykBhFAeYp9gkLyZE0zIMno9n4g19hmdY39scwqVkOXaxph0ZCXQcqxSpgQpONa59wkRDOL93eAXvimwlbPbwwVAegLS1HGfZAAAAABJRU5ErkJggg==\") no-repeat left center;background-size: 1em;}</style>";
const char HTTP_SCRIPT[] PROGMEM          = "<script>function c(l){document.getElementById('s').value=l.innerText||l.textContent;document.getElementById('p').focus();}</script>";
const char HTTP_HEAD_END[] PROGMEM        = "</head><body><div style='text-align:left;display:inline-block;min-width:260px;'>";
const char HTTP_PORTAL_OPTIONS[] PROGMEM  = "<form action=\"/wifi\" method=\"get\"><button>Configure WiFi</button></form><br/><form action=\"/0wifi\" method=\"get\"><button>Configure WiFi (No Scan)</button></form><br/><form action=\"/i\" method=\"get\"><button>Info</button></form><br/><form action=\"/r\" method=\"post\"><button>Reset</button></form>";
const char HTTP_ITEM[] PROGMEM            = "<div><a href='#p' onclick='c(this)'>{v}</a>&nbsp;<span class='q {i}'>{r}%</span></div>";
const char HTTP_FORM_START[] PROGMEM      = "<form method='post' action='save'><br/>";
const char HTTP_FORM_PARAM[] PROGMEM      = "<label for='{i}'>{p}</label><br/><input id='{i}' name='{n}' maxlength={l}  value='{v}' {c}><br/><br/>";
const char HTTP_UPDATE_LINK[] PROGMEM       = "<br/><div class=\"c\"><a href=\"/update\">Firmware upgrade</a></div>";
const char HTTP_FORM_END[] PROGMEM        = "<br/><button type='submit'>save</button></form><br/><form action=\"/reset\" method=\"get\"><button>Restart ESP</button></form>";
const char HTTP_SCAN_LINK[] PROGMEM       = "<br/><div class=\"c\"><a href=\"/wifi\">Scan</a></div>";
const char HTTP_SAVED[] PROGMEM           = "<div>Credentials Saved<br />Trying to connect ESP to network.<br />If it fails reconnect to AP to try again</div>";
const char HTTP_END[] PROGMEM             = "</div></body></html>";
const char HTTP_OPTION_ITEM[] PROGMEM     = "<option value=\"{v}\" {s}>{n}</option>";
const char HTTP_WG_LANGUAGES[] PROGMEM    = "See <a href='https://www.wunderground.com/weather/api/d/docs?d=language-support' target=_blank>Language Codes</a> for explanation.";

/*
const char country_0[] PROGMEM = "AF";
const char country_1[] PROGMEM = "AL";
const char country_2[] PROGMEM = "AR";
const char country_3[] PROGMEM = "AZ";
const char country_4[] PROGMEM = "BR";
const char country_5[] PROGMEM = "BU";
const char country_6[] PROGMEM = "BY";
const char country_7[] PROGMEM = "CA";
const char country_8[] PROGMEM = "CH";
const char country_9[] PROGMEM = "CN";
const char country_10[] PROGMEM = "CR";
const char country_11[] PROGMEM = "CY";
const char country_12[] PROGMEM = "CZ";
const char country_13[] PROGMEM = "DK";
const char country_14[] PROGMEM = "DL";
const char country_15[] PROGMEM = "DV";
const char country_16[] PROGMEM = "EN";
const char country_17[] PROGMEM = "EO";
const char country_18[] PROGMEM = "ET";
const char country_19[] PROGMEM = "EU";
const char country_20[] PROGMEM = "FA";
const char country_21[] PROGMEM = "FC";
const char country_22[] PROGMEM = "FI";
const char country_23[] PROGMEM = "FR";
const char country_24[] PROGMEM = "GM";
const char country_25[] PROGMEM = "GN";
const char country_26[] PROGMEM = "GR";
const char country_27[] PROGMEM = "GU";
const char country_28[] PROGMEM = "GZ";
const char country_29[] PROGMEM = "HI";
const char country_30[] PROGMEM = "HT";
const char country_31[] PROGMEM = "HU";
const char country_32[] PROGMEM = "HY";
const char country_33[] PROGMEM = "ID";
const char country_34[] PROGMEM = "IL";
const char country_35[] PROGMEM = "IO";
const char country_36[] PROGMEM = "IR";
const char country_37[] PROGMEM = "IS";
const char country_38[] PROGMEM = "IT";
const char country_39[] PROGMEM = "JI";
const char country_40[] PROGMEM = "JP";
const char country_41[] PROGMEM = "JW";
const char country_42[] PROGMEM = "KA";
const char country_43[] PROGMEM = "KM";
const char country_44[] PROGMEM = "KR";
const char country_45[] PROGMEM = "KU";
const char country_46[] PROGMEM = "LA";
const char country_47[] PROGMEM = "LI";
const char country_48[] PROGMEM = "LT";
const char country_49[] PROGMEM = "LV";
const char country_50[] PROGMEM = "MI";
const char country_51[] PROGMEM = "MK";
const char country_52[] PROGMEM = "MN";
const char country_53[] PROGMEM = "MR";
const char country_54[] PROGMEM = "MT";
const char country_55[] PROGMEM = "MY";
const char country_56[] PROGMEM = "ND";
const char country_57[] PROGMEM = "NL";
const char country_58[] PROGMEM = "NO";
const char country_59[] PROGMEM = "OC";
const char country_60[] PROGMEM = "PA";
const char country_61[] PROGMEM = "PL";
const char country_62[] PROGMEM = "PS";
const char country_63[] PROGMEM = "RO";
const char country_64[] PROGMEM = "RU";
const char country_65[] PROGMEM = "SI";
const char country_66[] PROGMEM = "SK";
const char country_67[] PROGMEM = "SL";
const char country_68[] PROGMEM = "SN";
const char country_69[] PROGMEM = "SP";
const char country_70[] PROGMEM = "SR";
const char country_71[] PROGMEM = "SW";
const char country_72[] PROGMEM = "TH";
const char country_73[] PROGMEM = "TK";
const char country_74[] PROGMEM = "TL";
const char country_75[] PROGMEM = "TR";
const char country_76[] PROGMEM = "TT";
const char country_77[] PROGMEM = "TW";
const char country_78[] PROGMEM = "UA";
const char country_79[] PROGMEM = "UZ";
const char country_80[] PROGMEM = "VU";
const char country_81[] PROGMEM = "YI";

const char* const country_table[] PROGMEM = {country_0, country_1, country_2, country_3, country_4, country_5, country_6, country_7, country_8, country_9, country_10, country_11, country_12, country_13, country_14, country_15, country_16, country_17, country_18, country_19, country_20, country_21, country_22, country_23, country_24, country_25, country_26, country_27, country_28, country_29, country_30, country_31, country_32, country_33, country_34, country_35, country_36, country_37, country_38, country_39, country_40, country_41, country_42, country_43, country_44, country_45, country_46, country_47, country_48, country_49, country_50, country_51, country_52, country_53, country_54, country_55, country_56, country_57, country_58, country_59, country_60, country_61, country_62, country_63, country_64, country_65, country_66, country_67, country_68, country_69, country_70, country_71, country_72, country_73, country_74, country_75, country_76, country_77, country_78, country_79, country_80, country_81};
*/

ESP8266WebServer server (80);

const char language_0[] PROGMEM = "Arabic|ar";
const char language_1[] PROGMEM = "Bulgarian|bg";
const char language_2[] PROGMEM = "Catalan|ca";
const char language_3[] PROGMEM = "Czech|cz";
const char language_4[] PROGMEM = "German|de";
const char language_5[] PROGMEM = "Greek|el";
const char language_6[] PROGMEM = "English|en";
const char language_7[] PROGMEM = "Persian (Farsi)|fa";
const char language_8[] PROGMEM = "Finnish|fi";
const char language_9[] PROGMEM = "French|fr";
const char language_10[] PROGMEM = "Galician|gl";
const char language_11[] PROGMEM = "Croatian|hr";
const char language_12[] PROGMEM = "Hungarian|hu";
const char language_13[] PROGMEM = "Italian|it";
const char language_14[] PROGMEM = "Japanese|ja";
const char language_15[] PROGMEM = "Korean|kr";
const char language_16[] PROGMEM = "Latvian|la";
const char language_17[] PROGMEM = "Lithuanian|lt";
const char language_18[] PROGMEM = "Macedonian|mk";
const char language_19[] PROGMEM = "Dutch|nl";
const char language_20[] PROGMEM = "Polish|pl";
const char language_21[] PROGMEM = "Portuguese|pt";
const char language_22[] PROGMEM = "Romanian|ro";
const char language_23[] PROGMEM = "Russian|ru";
const char language_24[] PROGMEM = "Swedish|se";
const char language_25[] PROGMEM = "Slovak|sk";
const char language_26[] PROGMEM = "Slovenian|sl";
const char language_27[] PROGMEM = "Spanish|es";
const char language_28[] PROGMEM = "Turkish|tr";
const char language_29[] PROGMEM = "Ukrainian|ua";
const char language_30[] PROGMEM = "Vietnamese|vi";
const char language_31[] PROGMEM = "Chinese Simplified|zh_cn";
const char language_32[] PROGMEM = "Chinese Traditional|zh_tw";

const char* const language_table[] PROGMEM = {language_0, language_1, language_2, language_3, language_4, language_5, language_6,
  language_7, language_8, language_9, language_10, language_11, language_12, language_13, language_14, language_16, language_17,
  language_18, language_19, language_20, language_21, language_22, language_23, language_24, language_25, language_26, language_27,
  language_28, language_29, language_30, language_31, language_32};


String getFormField(String id, String placeholder, String length, String value, String customHTML) {
    String pitem = FPSTR(HTTP_FORM_PARAM);

    pitem.replace("{i}", id);
    pitem.replace("{n}", id);
    pitem.replace("{p}", placeholder);
    pitem.replace("{l}", length);
    pitem.replace("{v}", value);
    pitem.replace("{c}", customHTML);
  return pitem;
}


boolean saveConfig() {
  File f = SPIFFS.open("/espaper.txt", "w+");
  if (!f) {
    Serial.println("Failed to open config file");
    return false;
  }
  f.print("BOARD_TYPE=");
  f.println(BOARD_TYPE);
  f.print("WIFI_SSID=");
  f.println(WIFI_SSID);
  f.print("WIFI_PASS=");
  f.println(WIFI_PASS);
  f.print("CITY=");
  f.println(CITY);
  f.print("COUNTRY=");
  f.println(COUNTRY);
  f.print("LANGUAGE=");
  f.println(LANGUAGE);
  f.print("WUNDERGRROUND_API_KEY=");
  f.println(WUNDERGRROUND_API_KEY);

  f.print("DISPLAYED_CITY_NAME=");
  f.println(DISPLAYED_CITY_NAME);
  f.print("OPEN_WEATHER_MAP_APP_ID=");
  f.println(OPEN_WEATHER_MAP_APP_ID);
  f.print("OPEN_WEATHER_MAP_LOCATION_ID=");
  f.println(OPEN_WEATHER_MAP_LOCATION_ID);
  f.print("OPEN_WEATHER_MAP_LANGUAGE=");
  f.println(OPEN_WEATHER_MAP_LANGUAGE);  

  f.print("UTC_OFFSET=");
  f.println(UTC_OFFSET);
  
  f.close();
  Serial.println("Saved values");
  return true;
}

boolean loadConfig() {
  File f = SPIFFS.open("/espaper.txt", "r");
  if (!f) {
    Serial.println("Failed to open config file");
    return false;
  }
  while(f.available()) {
      //Lets read line by line from the file
      String key = f.readStringUntil('=');
      String value = f.readStringUntil('\r');
      f.read();
      Serial.println(key + " = [" + value + "]");
      Serial.println(key.length());
      if (key == "BOARD_TYPE") {
        BOARD_TYPE = value;
      }
      if (key == "WIFI_SSID") {
        WIFI_SSID = value;
      }
      if (key == "WIFI_PASS") {
        WIFI_PASS = value;
      }
      if (key == "CITY") {
        CITY = value;
      }
      if (key == "COUNTRY") {
        COUNTRY = value;
      }
      if (key == "LANGUAGE") {
        LANGUAGE = value;
      }
      if (key == "WUNDERGRROUND_API_KEY") {
        WUNDERGRROUND_API_KEY = value;
      }

      if (key == "DISPLAYED_CITY_NAME") {
        DISPLAYED_CITY_NAME = value;
      }
      if (key == "OPEN_WEATHER_MAP_APP_ID") {
        OPEN_WEATHER_MAP_APP_ID = value;
      }
      if (key == "OPEN_WEATHER_MAP_LOCATION_ID") {
        OPEN_WEATHER_MAP_LOCATION_ID = value;
      }
      if (key == "OPEN_WEATHER_MAP_LANGUAGE") {
        OPEN_WEATHER_MAP_LANGUAGE = value;
      }      

      if (key == "UTC_OFFSET") {
        UTC_OFFSET = value.toInt();
      }      
  }

  f.close();
  Serial.println("Loaded config");
  return true;
}

void handleRoot() {
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.sendHeader("Content-Type","text/html",true);
  server.sendHeader("Cache-Control","no-cache");
  server.send(200); 

  String page = FPSTR(HTTP_HEAD);
  page.replace("{v}", "Options");
  page += FPSTR(HTTP_SCRIPT);
  page += FPSTR(HTTP_STYLE);
  //page += _customHeadElement;
  page += FPSTR(HTTP_HEAD_END);
  page += "<h1>AZSMZ ePaper Configuration</h1>";

  //page += FPSTR(HTTP_PORTAL_OPTIONS);
  page += FPSTR(HTTP_FORM_START);
  page += getFormField("ssid", "WiFi SSID", "20", WIFI_SSID, "");
  page += getFormField("password", "WiFi Password", "20", WIFI_PASS, "");

  server.sendContent(page); page = "";  

/*
  page += getFormField("city", "City", "40", CITY, "");
  page += getFormField("country", "Country", "40", COUNTRY, "");
  page += "<label for=\"language\">Language</label>";
  page += "<select id=\"language\" name=\"language\">";
  Serial.println(LANGUAGE);
  for (int i = 0; i < 82; i++) {
    String option = FPSTR(HTTP_OPTION_ITEM);
    String country = FPSTR(country_table[i]);
    option.replace("{v}", country);
    option.replace("{n}", country);
    if (country == LANGUAGE) {
      option.replace("{s}", "selected");
    } else {
      option.replace("{s}", "");
    }
    page += option;
  }
  page += "</select>";
  page += FPSTR(HTTP_WG_LANGUAGES);
*/

  page += getFormField("displayedcityname", "Displayed City Name", "40", DISPLAYED_CITY_NAME, "");
  page += getFormField("openweathermapkey", "OpenWeatherMap App ID", "40", OPEN_WEATHER_MAP_APP_ID.substring(0,3)+ "***"+ OPEN_WEATHER_MAP_APP_ID.substring(OPEN_WEATHER_MAP_APP_ID.length()-3), "");
  page += getFormField("openweathermaplocationid", "OpenWeatherMap Location ID (e.g. 2657896)", "40", OPEN_WEATHER_MAP_LOCATION_ID, "");
  page += "<label for=\"openweathermaplanguage\">OpenWeatherMap Language</label>";
  page += "<select id=\"openweathermaplanguage\" name=\"openweathermaplanguage\">";

  server.sendContent(page); page = "";

  for (int i = 0; i < 32; i++) {
    String option = FPSTR(HTTP_OPTION_ITEM);
    String language = FPSTR(language_table[i]);
    int separatorPos = language.indexOf("|");

    String label = language.substring(0, separatorPos);
    String key = language.substring(separatorPos + 1);
    option.replace("{v}", key);
    option.replace("{n}", label);
    if (key == OPEN_WEATHER_MAP_LANGUAGE) {
      option.replace("{s}", "selected");
    } else {
      option.replace("{s}", "");
    }
    
    page += option;
  }
  
  page += "</select>";
  
  server.sendContent(page); page = "";
  
//  page += "<br/>";
//  page += getFormField("wundergroundkey", "Wunderground API Key", "40", WUNDERGRROUND_API_KEY, "");
//  page += getFormField("wundergroundkey", "Wunderground API Key", "40", WUNDERGRROUND_API_KEY.substring(0,3) + "***"+ WUNDERGRROUND_API_KEY.substring(WUNDERGRROUND_API_KEY.length()-3), "");
 
//  page += getFormField("UTC_OFFSET", "time zone", "40", String(UTC_OFFSET), "");

  page += "<br/><br/>";

  page += FPSTR(HTTP_FORM_END);
  page += FPSTR(HTTP_UPDATE_LINK);
  page += FPSTR(HTTP_END);

  server.sendContent(page); page = "";
  server.sendContent("");
}

void handleSave() {
  WIFI_SSID = server.arg("ssid");
  WIFI_PASS = server.arg("password");
  CITY = server.arg("city");
  COUNTRY = server.arg("country");
  LANGUAGE = server.arg("language");
//  WUNDERGRROUND_API_KEY = server.arg("wundergroundkey");
  String apiKey = server.arg("wundergroundkey");
  if (apiKey.length()> 10) WUNDERGRROUND_API_KEY = server.arg("wundergroundkey");

  DISPLAYED_CITY_NAME = server.arg("displayedcityname");
  apiKey = server.arg("openweathermapkey");
  if (apiKey.length()> 10) OPEN_WEATHER_MAP_APP_ID = server.arg("openweathermapkey");
  OPEN_WEATHER_MAP_LOCATION_ID = server.arg("openweathermaplocationid");
  OPEN_WEATHER_MAP_LANGUAGE = server.arg("openweathermaplanguage");
  Serial.println(WIFI_SSID);
  Serial.println(WIFI_PASS);
/*  
  Serial.println(CITY);
  Serial.println(COUNTRY);
  Serial.println(LANGUAGE);
  Serial.println(WUNDERGRROUND_API_KEY);
*/
  Serial.println(DISPLAYED_CITY_NAME);
  Serial.println(OPEN_WEATHER_MAP_APP_ID);
  Serial.println(OPEN_WEATHER_MAP_LOCATION_ID);
  Serial.println(OPEN_WEATHER_MAP_LANGUAGE);  

  UTC_OFFSET = server.arg("UTC_OFFSET").toInt();  
  saveConfig();
  handleRoot();
}

void handleNotFound() {
  //digitalWrite ( led, 1 );
  String message = "File Not Found\n\n";
  message += "URI: ";
  message += server.uri();
  message += "\nMethod: ";
  message += ( server.method() == HTTP_GET ) ? "GET" : "POST";
  message += "\nArguments: ";
  message += server.args();
  message += "\n";

  for ( uint8_t i = 0; i < server.args(); i++ ) {
    message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
  }

  server.send ( 404, "text/plain", message );
  //digitalWrite ( led, 0 );
}

void startConfigPortal(MiniGrafx *gfx) {
  server.on ( "/", handleRoot );
  server.on ( "/save", handleSave);
  server.on ( "/reset", []() {
     saveConfig();
     ESP.restart();
  } );
  server.onNotFound ( handleNotFound ); 
  server.begin();
  boolean connected = WiFi.status() == WL_CONNECTED;
  gfx->fillBuffer(1);
  gfx->setColor(0);
  gfx->setTextAlignment(TEXT_ALIGN_CENTER);
  gfx->setFont(ArialMT_Plain_16);
  if (connected) {
      Serial.println ( "Open browser at http://" + WiFi.localIP().toString());
      gfx->drawString(296 / 2, 10, "AZSMZ ePaper Setup Mode\nConnected to: " + WiFi.SSID() + "\nOpen browser at\nhttp://" + WiFi.localIP().toString());    
  } else {
      WiFi.mode(WIFI_AP);
      WiFi.softAP((ESP.getChipId()+CONFIG_SSID).c_str());
      IPAddress myIP = WiFi.softAPIP();  
      Serial.println(myIP);
      gfx->drawString(296 / 2, 10, "AZSMZ ePaper Setup Mode\nConnect WiFi to:\n" + String(ESP.getChipId()) + CONFIG_SSID + "\nOpen browser at\nhttp://" + myIP.toString());
  }

  gfx->commit();

  Serial.println ( "HTTP server started" );

  long startTime = millis();
  while(millis()-startTime< 300 * 1000) {  
    server.handleClient();
    yield();
  }

  gfx->fillBuffer(1);
  gfx->drawString(296 / 2, 128 / 2 - 30, "Could not connect to WiFi\nPress LEFT + RIGHT button\nto enter config mode");
  gfx->commit();
  ESP.deepSleep(UPDATE_INTERVAL_SECS * 1000000);
}
